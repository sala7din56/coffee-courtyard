<?php
$cssPath = 'D:/xampp/htdocs/coffee-courtyard-main/coffee-courtyard-main/public/css/dist.css';

// Additional CSS for better cart sizing
$additionalCss = '
/* Order cart sizing and layout improvements */
.max-h-64{max-height:16rem}
.max-h-screen{max-height:100vh}
.p-6{padding:1.5rem}
.py-2\.5{padding-top:0.625rem;padding-bottom:0.625rem}
.px-3{padding-left:0.75rem;padding-right:0.75rem}
.mb-1\.5{margin-bottom:0.375rem}
.mb-3{margin-bottom:0.75rem}
.mb-4{margin-bottom:1rem}
.mb-5{margin-bottom:1.25rem}
.mb-8{margin-bottom:2rem}
.pt-4{padding-top:1rem}
.space-y-4>:not([hidden])~:not([hidden]){margin-top:1rem}
.space-y-3>:not([hidden])~:not([hidden]){margin-top:0.75rem}
.space-y-2>:not([hidden])~:not([hidden]){margin-top:0.5rem}
.text-xs{font-size:0.75rem;line-height:1rem}
.w-5{width:1.25rem}
.h-5{height:1.25rem}
.w-6{width:1.5rem}
.w-80{width:20rem}
.w-96{width:24rem}
.lg\:w-96{width:24rem}
.flex-shrink-0{flex-shrink:0}
.fixed{position:fixed}
.inset-0{inset:0}
.z-40{z-index:40}
.right-0{right:0}
.bottom-4{bottom:1rem}
.right-4{right:1rem}
.top-4{top:1rem}
.max-w-sm{max-width:24rem}
.shadow-lg{box-shadow:0 10px 15px -3px rgba(0,0,0,.1),0 4px 6px -2px rgba(0,0,0,.05)}
.shadow-md{box-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -1px rgba(0,0,0,.06)}
.focus\:ring-primary\/50:focus{--tw-ring-color:rgba(221,161,94,0.5)}
.focus\:border-primary:focus{border-color:#dda15e}
.col-span-full{grid-column:1/-1}
.line-clamp-2{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.bg-black\/50{background-color:rgba(0,0,0,0.5)}
.bg-green-100{background-color:#dcfce7}
.text-green-800{color:#166534}
.bg-red-100{background-color:#fee2e2}
.text-red-800{color:#991b1b}
.text-3xl{font-size:1.875rem;line-height:2.25rem}
.text-4xl{font-size:2.25rem;line-height:2.5rem}
.primary\/30{color:rgba(221,161,94,0.3)}

/* Responsive breakpoints */
@media (min-width:1024px){
.lg\:hidden{display:none}
.lg\:block{display:block}
.lg\:relative{position:relative}
.lg\:inset-auto{inset:auto}
.lg\:bg-transparent{background-color:transparent}
.lg\:max-w-none{max-width:none}
.lg\:h-auto{height:auto}
.lg\:max-h-screen{max-height:100vh}
.lg\:rounded-xl{border-radius:0.75rem}
.lg\:border{border-style:var(--tw-border-style);border-width:1px}
.lg\:border-primary\/20{border-color:rgba(221,161,94,0.2)}
.lg\:shadow-md{box-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -1px rgba(0,0,0,.06)}
.lg\:sticky{position:sticky}
.lg\:top-4{top:1rem}
.lg\:w-96{width:24rem}
.lg\:flex-row{flex-direction:row}
}

@media (min-width:1280px){
.xl\:grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))}
.xl\:w-96{width:24rem}
}

/* Better mobile cart panel */
@media (max-width:1023px){
#cart-panel.active{display:flex}
}
';

// Append the additional CSS
$currentCss = file_get_contents($cssPath);
file_put_contents($cssPath, $currentCss . $additionalCss);
echo "CSS updated successfully with cart improvements!\n";
