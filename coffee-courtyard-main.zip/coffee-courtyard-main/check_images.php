<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();

echo "Menu Items with Image Paths:\n";
echo "============================\n\n";

$result = $db->query("SELECT id, name, image_path FROM menu_items");
while ($row = $result->fetch_assoc()) {
    $imagePath = $row['image_path'];
    $fullPath = __DIR__ . '/coffee-courtyard-main/public/images/uploads/' . $imagePath;
    $exists = file_exists($fullPath) ? 'EXISTS' : 'MISSING';

    echo "ID: " . $row['id'] . "\n";
    echo "Name: " . $row['name'] . "\n";
    echo "Image: " . ($imagePath ?: '(none)') . "\n";
    echo "Status: " . $exists . "\n";
    echo "---\n";
}
?>
