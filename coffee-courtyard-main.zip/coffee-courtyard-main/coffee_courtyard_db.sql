-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2025 at 09:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coffee_courtyard_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password_hash`, `created_at`, `last_login`) VALUES
(1, 'admin', '$2y$10$lH9dGt7rgWz3alLp2uXr4uhqA1VfkqCldKIIjnTTdJTwUbr8B6saS', '2025-11-13 12:52:31', '2025-11-21 19:36:37');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `position` varchar(255) DEFAULT NULL,
  `hourly_wage` decimal(10,2) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `full_name`, `position`, `hourly_wage`, `hire_date`, `created_at`) VALUES
(1, 'john fry', 'manger ', 1800.00, '2023-06-19', '2025-11-21 19:21:59'),
(2, 'sara smith ', 'head chef', 2000.00, '2025-07-21', '2025-11-21 19:22:49'),
(3, 'luk combs', 'cashier', 600.00, '2025-11-05', '2025-11-21 19:24:13'),
(4, 'Kevin walker', 'waiter', 450.00, '2025-11-05', '2025-11-21 19:25:30'),
(5, 'Alisa Robinson ', 'waiter', 450.00, '2025-01-09', '2025-11-21 19:26:09'),
(6, 'Amanda gray', 'sous chef', 900.00, '2023-01-19', '2025-11-21 19:26:58');

-- --------------------------------------------------------

--
-- Table structure for table `homepage_content`
--

CREATE TABLE `homepage_content` (
  `id` int(11) NOT NULL,
  `section_name` varchar(255) NOT NULL,
  `content_text` longtext DEFAULT NULL,
  `content_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `homepage_content`
--

INSERT INTO `homepage_content` (`id`, `section_name`, `content_text`, `content_image`, `created_at`, `updated_at`) VALUES
(1, 'hero_title', 'Every cup holds a new beginning and Your dreams need caffeine too', 'hero-bg.jpg', '2025-11-13 12:52:31', '2025-11-21 20:07:55'),
(2, 'hero_subtitle', '', NULL, '2025-11-13 12:52:31', '2025-11-21 20:17:09'),
(3, 'about_title', 'Our Story', NULL, '2025-11-13 12:52:31', '2025-11-13 12:52:31'),
(4, 'about_text', 'Coffee CourtYard was born from a simple idea: to create a warm and inviting space where the community can gather, relax, and enjoy exceptionally crafted coffee. We\'re passionate about sourcing the finest specialty beans, partnering with local bakeries, and providing a tranquil escape from the everyday hustle. Our mission is to pour our heart into every cup and make you feel right at home in our cozy courtyard.', NULL, '2025-11-13 12:52:31', '2025-11-13 12:52:31'),
(5, 'contact_address', 'Farmanbaran City', NULL, '2025-11-13 12:52:31', '2025-11-14 14:13:20'),
(6, 'contact_email', 'test@test.com', NULL, '2025-11-13 12:52:31', '2025-11-14 14:13:05'),
(7, 'contact_phone', '07501847702', NULL, '2025-11-13 12:52:31', '2025-11-14 14:12:52');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `category` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `name`, `description`, `price`, `image_path`, `category`, `created_at`, `updated_at`) VALUES
(1, 'Espresso', 'A concentrated coffee brew with a rich aroma and a caramel-like sweetness.', 3.00, '6920966eb9764_1763743342.jpeg', 'Hot Coffee', '2025-11-13 12:52:31', '2025-11-21 16:42:22'),
(2, 'Americano', 'Espresso shots topped with hot water create a light layer of crema.', 3.50, '6920971b64dc2_1763743515.jpeg', 'Hot Coffee', '2025-11-13 12:52:31', '2025-11-21 16:45:15'),
(3, 'Latte', 'Rich espresso with steamed milk and a light layer of foam.', 4.50, '692096a9668e0_1763743401.jpeg', 'Hot Coffee', '2025-11-13 12:52:31', '2025-11-21 16:43:21'),
(4, 'Cappuccino', 'A perfect balance of espresso, steamed milk, and a thick layer of foam.', 4.50, '692096bc92396_1763743420.jpeg', 'Hot Coffee', '2025-11-13 12:52:31', '2025-11-21 16:43:40'),
(5, 'Mocha', 'Espresso combined with rich chocolate and steamed milk.', 4.75, '69209688bfc7e_1763743368.jpeg', 'Hot Coffee', '2025-11-13 12:52:31', '2025-11-21 16:42:48'),
(6, 'Iced Latte', 'Chilled espresso with milk, served over ice for a refreshing kick.', 5.00, '69209591de004_1763743121.jpeg', 'Iced Drinks', '2025-11-13 12:52:31', '2025-11-21 16:38:41'),
(7, 'Cold Brew', 'Slow-steeped for 12 hours for a smooth, low-acid, and bold coffee flavor.', 4.75, '6920959e7e7c9_1763743134.jpeg', 'Iced Drinks', '2025-11-13 12:52:31', '2025-11-21 16:38:54'),
(8, 'Iced Americano', 'Rich espresso shots combined with cold water and ice. Crisp and invigorating.', 3.75, '692095a7ef67b_1763743143.jpeg', 'Iced Drinks', '2025-11-13 12:52:31', '2025-11-21 16:39:03'),
(9, 'Butter Croissant', 'Flaky, buttery, and freshly baked throughout the day.', 3.50, '692095777a7cd_1763743095.jpeg', 'Pastries', '2025-11-13 12:52:31', '2025-11-21 16:38:15'),
(10, 'Blueberry Muffin', 'A soft, moist muffin bursting with juicy blueberries.', 3.75, '6920957f523a6_1763743103.jpeg', 'Pastries', '2025-11-13 12:52:31', '2025-11-21 16:38:23'),
(11, 'Chocolate Chip Cookie', 'Classic and chewy, loaded with rich chocolate chips.', 2.50, '69209660665b2_1763743328.jpeg', 'Pastries', '2025-11-13 12:52:31', '2025-11-21 16:42:08'),
(12, 'Almond Croissant', 'Buttery croissant filled with sweet almond cream.', 4.00, '692095886b378_1763743112.jpeg', 'Pastries', '2025-11-13 12:52:31', '2025-11-21 16:38:32'),
(13, 'Avocado Toast', 'Fresh avocado on toasted artisan bread with a hint of lemon.', 6.50, '6920951622275_1763742998.jpeg', 'Food', '2025-11-13 12:52:31', '2025-11-21 16:36:38'),
(14, 'Turkey Sandwich', 'Roasted turkey with fresh vegetables on whole grain bread.', 10.00, '6920952aa4f99_1763743018.jpeg', 'Food', '2025-11-13 12:52:31', '2025-11-21 16:36:58');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `phone`, `total`, `created_at`) VALUES
(2, 'aaa', '2222', 23.50, '2025-11-21 18:04:54'),
(3, 'john algamig', '12346676', 12.00, '2025-11-21 18:05:04'),
(4, 'kaka rot', '6544568', 21.25, '2025-11-21 19:29:57'),
(5, 'eee', '43444', 20.00, '2025-11-21 19:48:48');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `menu_id`, `qty`, `unit_price`) VALUES
(2, 2, 2, 1, 3.50),
(3, 2, 14, 2, 10.00),
(4, 3, 3, 1, 4.50),
(5, 3, 1, 1, 3.00),
(6, 3, 4, 1, 4.50),
(7, 4, 13, 1, 6.50),
(8, 4, 14, 1, 10.00),
(9, 4, 7, 1, 4.75),
(10, 5, 2, 1, 3.50),
(11, 5, 14, 1, 10.00),
(12, 5, 13, 1, 6.50);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `homepage_content`
--
ALTER TABLE `homepage_content`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `section_name` (`section_name`),
  ADD KEY `idx_homepage_section` (`section_name`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_menu_category` (`category`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `menu_id` (`menu_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `homepage_content`
--
ALTER TABLE `homepage_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`menu_id`) REFERENCES `menu_items` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
