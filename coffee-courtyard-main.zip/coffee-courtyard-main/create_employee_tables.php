<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();
$sqlFile = __DIR__ . '/coffee-courtyard-main/database/employee_tables.sql';

if (!file_exists($sqlFile)) {
    die("Error: SQL file not found at " . $sqlFile);
}

$sql = file_get_contents($sqlFile);

try {
    $db->query($sql);
    echo "Table 'employees' created successfully!\n";
} catch (Exception $e) {
    die("Error creating table: " . $e->getMessage());
}
?>
