<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();
$sqlFile = __DIR__ . '/coffee-courtyard-main/database/order_tables.sql';

if (!file_exists($sqlFile)) {
    die("Error: SQL file not found at " . $sqlFile);
}

$sql = file_get_contents($sqlFile);

echo "Attempting to execute SQL from: " . $sqlFile . "\n";

try {
    // Split the SQL into individual statements
    $statements = array_filter(array_map('trim', explode(';', $sql)));

    if (empty($statements)) {
        die("Error: SQL file is empty or contains no valid statements.\n");
    }

    foreach ($statements as $statement) {
        if (!empty($statement)) {
            echo "Executing statement: " . $statement . "\n";
            $db->query($statement);
            echo "Statement executed successfully.\n";
        }
    }

    echo "Tables 'orders' and 'order_items' created successfully!\n";
} catch (Exception $e) {
    die("Error creating tables: " . $e->getMessage());
}
?>