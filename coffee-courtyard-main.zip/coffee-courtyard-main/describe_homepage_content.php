<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();

echo "Describing 'homepage_content' table...\n";
echo "======================================\n";

try {
    $result = $db->query("DESCRIBE homepage_content");
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "Field: " . $row['Field'] . ", Type: " . $row['Type'] . ", Null: " . $row['Null'] . ", Key: " . $row['Key'] . ", Default: " . $row['Default'] . ", Extra: " . $row['Extra'] . "\n";
        }
    } else {
        echo "Table 'homepage_content' not found or has no columns.\n";
    }
} catch (Exception $e) {
    echo "Error describing table: " . $e->getMessage() . "\n";
}

$db->close();
?>
