<?php
$configPath = 'D:/xampp/htdocs/coffee-courtyard-main/coffee-courtyard-main/includes/config.php';
$content = file_get_contents($configPath);
$content = str_replace(
    "define('BASE_URL', 'http://localhost:8080/CoffeeCourtyard');",
    "define('BASE_URL', 'http://localhost:8080/coffee-courtyard-main/coffee-courtyard-main');",
    $content
);
file_put_contents($configPath, $content);
echo "BASE_URL updated successfully!\n";
echo "New value: http://localhost:8080/coffee-courtyard-main/coffee-courtyard-main\n";
?>
