<?php
$cssPath = 'D:/xampp/htdocs/coffee-courtyard-main/coffee-courtyard-main/public/css/dist.css';

// Custom theme colors to add at the beginning
$themeColors = '/*! tailwindcss v4.1.17 | MIT License | https://tailwindcss.com */

/* Custom Theme Colors - Coffee CourtYard */
.bg-primary{background-color:#dda15e}
.bg-background-light{background-color:#fefae0}
.bg-background-dark{background-color:#201912}
.bg-white{background-color:#fff}
.text-primary{color:#dda15e}
.text-text-primary-light{color:#283618}
.text-text-secondary-light{color:#606c38}
.text-text-accent-light{color:#bc6c25}
.text-text-primary-dark{color:#fefae0}
.text-text-secondary-dark{color:#a3b18a}
.text-text-accent-dark{color:#dda15e}
.text-background-light{color:#fefae0}
.text-background-light\/90{color:rgba(254,250,224,0.9)}
.text-white{color:#fff}
.border-primary{border-color:#dda15e}
.border-primary\/20{border-color:rgba(221,161,94,0.2)}
.border-primary\/30{border-color:rgba(221,161,94,0.3)}
.bg-primary\/10{background-color:rgba(221,161,94,0.1)}
.bg-white\/5{background-color:rgba(255,255,255,0.05)}
.dark .dark\:bg-background-dark{background-color:#201912}
.dark .dark\:bg-white\/5{background-color:rgba(255,255,255,0.05)}
.dark .dark\:text-text-primary-dark{color:#fefae0}
.dark .dark\:text-text-secondary-dark{color:#a3b18a}
.dark .dark\:text-text-accent-dark{color:#dda15e}
.dark .dark\:border-primary\/20{border-color:rgba(221,161,94,0.2)}
.dark .dark\:border-primary\/30{border-color:rgba(221,161,94,0.3)}
.font-display{font-family:"Plus Jakarta Sans",sans-serif}
.rounded-lg{border-radius:0.5rem}
.rounded-xl{border-radius:0.75rem}
.h-10{height:2.5rem}
.h-12{height:3rem}
.h-48{height:12rem}
.px-4{padding-left:1rem;padding-right:1rem}
.px-5{padding-left:1.25rem;padding-right:1.25rem}
.py-3{padding-top:0.75rem;padding-bottom:0.75rem}
.py-5{padding-top:1.25rem;padding-bottom:1.25rem}
.p-4{padding:1rem}
.p-5{padding:1.25rem}
.p-8{padding:2rem}
.gap-1{gap:0.25rem}
.gap-3{gap:0.75rem}
.gap-4{gap:1rem}
.gap-6{gap:1.5rem}
.gap-8{gap:2rem}
.gap-10{gap:2.5rem}
.gap-12{gap:3rem}
.mb-2{margin-bottom:0.5rem}
.mb-6{margin-bottom:1.5rem}
.mb-10{margin-bottom:2.5rem}
.mb-12{margin-bottom:3rem}
.mt-1{margin-top:0.25rem}
.mt-2{margin-top:0.5rem}
.mt-4{margin-top:1rem}
.mt-6{margin-top:1.5rem}
.space-y-1>:not([hidden])~:not([hidden]){margin-top:0.25rem}
.max-w-3xl{max-width:48rem}
.max-w-6xl{max-width:72rem}
.text-sm{font-size:0.875rem;line-height:1.25rem}
.text-base{font-size:1rem;line-height:1.5rem}
.text-lg{font-size:1.125rem;line-height:1.75rem}
.text-2xl{font-size:1.5rem;line-height:2rem}
.text-3xl{font-size:1.875rem;line-height:2.25rem}
.text-4xl{font-size:2.25rem;line-height:2.5rem}
.font-normal{font-weight:400}
.font-medium{font-weight:500}
.font-bold{font-weight:700}
.font-black{font-weight:900}
.leading-tight{line-height:1.25}
.leading-normal{line-height:1.5}
.leading-relaxed{line-height:1.625}
.tracking-tight{letter-spacing:-0.025em}
.tracking-wide{letter-spacing:0.025em}
@media (min-width:768px){
.md\:flex{display:flex}
.md\:grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))}
.md\:grid-cols-4{grid-template-columns:repeat(4,minmax(0,1fr))}
.md\:text-lg{font-size:1.125rem;line-height:1.75rem}
.md\:text-6xl{font-size:3.75rem;line-height:1}
}
@media (min-width:640px){
.sm\:grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (min-width:1024px){
.lg\:grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))}
.lg\:grid-cols-4{grid-template-columns:repeat(4,minmax(0,1fr))}
}
.top-0{top:0}
.backdrop-blur-sm{backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)}
.bg-background-light\/80{background-color:rgba(254,250,224,0.8)}
.dark .dark\:bg-background-dark\/80{background-color:rgba(32,25,18,0.8)}
@media (hover:hover){
.hover\:text-text-accent-light:hover{color:#bc6c25}
.dark .dark\:hover\:text-text-accent-dark:hover{color:#dda15e}
}

';

// Read existing CSS
$existingCss = file_get_contents($cssPath);

// Remove the first line (old tailwind comment) if it exists
$existingCss = preg_replace('/^\/\*! tailwindcss.*?\*\/\s*/s', '', $existingCss);

// Combine theme colors with existing CSS
$newCss = $themeColors . $existingCss;

// Write the updated CSS
file_put_contents($cssPath, $newCss);

echo "CSS updated with theme colors!\n";
echo "File: $cssPath\n";
?>
