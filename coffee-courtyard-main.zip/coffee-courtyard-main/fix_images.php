<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();

// Get all uploaded images sorted by filename (which includes timestamp)
$uploadDir = __DIR__ . '/coffee-courtyard-main/public/images/uploads/';
$images = glob($uploadDir . '*.jpeg');
sort($images);

// Extract just filenames
$imageFiles = array_map('basename', $images);

echo "Found " . count($imageFiles) . " images\n";
echo "Found 14 menu items\n\n";

// Map images to menu items (14 items, 14 images)
// Order: Espresso, Americano, Latte, Cappuccino, Mocha, Iced Latte, Cold Brew,
//        Iced Americano, Butter Croissant, Blueberry Muffin, Chocolate Chip Cookie,
//        Almond Croissant, Avocado Toast, Turkey Sandwich

if (count($imageFiles) >= 14) {
    for ($i = 1; $i <= 14; $i++) {
        $imageName = $imageFiles[$i - 1];
        $stmt = $db->prepare("UPDATE menu_items SET image_path = ? WHERE id = ?");
        $stmt->bind_param("si", $imageName, $i);
        $stmt->execute();

        // Get item name for display
        $result = $db->query("SELECT name FROM menu_items WHERE id = $i");
        $row = $result->fetch_assoc();

        echo "Updated ID $i ({$row['name']}): $imageName\n";
    }

    echo "\n✓ All menu item images updated successfully!\n";
} else {
    echo "Error: Not enough images found. Expected 14, found " . count($imageFiles) . "\n";
}
?>
