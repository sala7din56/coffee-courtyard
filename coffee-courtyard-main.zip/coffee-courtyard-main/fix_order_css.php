<?php
$cssPath = 'D:/xampp/htdocs/coffee-courtyard-main/coffee-courtyard-main/public/css/dist.css';

// Additional CSS for better cart sizing
$additionalCss = '
/* Order cart sizing fixes */
.flex-shrink-0{flex-shrink:0}
.h-auto{height:auto}
.max-h-48{max-height:12rem}
.text-xl{font-size:1.25rem;line-height:1.75rem}
.py-2\.5{padding-top:0.625rem;padding-bottom:0.625rem}
.top-3{top:0.75rem}
.right-3{right:0.75rem}
.shadow-md{box-shadow:0 4px 6px -1px rgba(0,0,0,0.1),0 2px 4px -2px rgba(0,0,0,0.1)}
.flex-row{flex-direction:row}
@media (min-width:1024px){
.lg\:w-80{width:20rem}
.lg\:flex-row{flex-direction:row}
.lg\:h-auto{height:auto}
}
@media (min-width:1280px){
.xl\:w-96{width:24rem}
.xl\:grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))}
}
';

// Read existing CSS and append
$existingCss = file_get_contents($cssPath);
$existingCss .= $additionalCss;
file_put_contents($cssPath, $existingCss);

echo "CSS updated with cart sizing fixes!\n";
?>
