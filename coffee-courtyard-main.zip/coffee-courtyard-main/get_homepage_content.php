<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();

echo "Content of 'homepage_content' table:\n";
echo "=====================================\n";

try {
    $result = $db->query("SELECT section_name, content_text FROM homepage_content");
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "Section Name: " . $row['section_name'] . ", Content Text: " . $row['content_text'] . "\n";
        }
    } else {
        echo "No entries found in 'homepage_content' table.\n";
    }
} catch (Exception $e) {
    echo "Error fetching data: " . $e->getMessage() . "\n";
}

$db->close();
?>
