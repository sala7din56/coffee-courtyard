<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();

echo "Listing all tables in the database:\n";
echo "===================================\n";

try {
    $result = $db->query("SHOW TABLES");
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_array(MYSQLI_NUM)) {
            echo "- " . $row[0] . "\n";
        }
    } else {
        echo "No tables found.\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
