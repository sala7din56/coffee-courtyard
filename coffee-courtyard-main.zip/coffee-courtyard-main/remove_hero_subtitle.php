<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();

$newHeroSubtitle = ""; // Empty string to remove the content
$contentKey = "hero_subtitle"; // The key for the hero section subtitle

try {
    $query = "UPDATE homepage_content SET content_text = ? WHERE section_name = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("ss", $newHeroSubtitle, $contentKey);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Hero section subtitle removed successfully.\n";
    } else {
        echo "No changes made or content key not found. Please check if 'hero_subtitle' exists in homepage_content.\n";
    }
} catch (Exception $e) {
    echo "Error updating hero section subtitle: " . $e->getMessage() . "\n";
}

$db->close();
?>
