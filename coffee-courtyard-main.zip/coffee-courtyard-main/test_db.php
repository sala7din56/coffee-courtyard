<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

echo "Testing Database Connection...\n";
echo "============================\n\n";

try {
    $db = new Database();
    echo "✓ Database connection: SUCCESS\n\n";

    // List tables
    $result = $db->query("SHOW TABLES");
    echo "Tables in database:\n";
    while ($row = $result->fetch_array()) {
        echo "  - " . $row[0] . "\n";
    }
    echo "\n";

    // Check admin_users
    $result = $db->query("SELECT COUNT(*) as count FROM admin_users");
    $row = $result->fetch_assoc();
    echo "Admin users: " . $row['count'] . "\n";

    // Check menu_items
    $result = $db->query("SELECT COUNT(*) as count FROM menu_items");
    $row = $result->fetch_assoc();
    echo "Menu items: " . $row['count'] . "\n";

    // Check homepage_content
    $result = $db->query("SELECT COUNT(*) as count FROM homepage_content");
    $row = $result->fetch_assoc();
    echo "Homepage content entries: " . $row['count'] . "\n\n";

    // List menu categories
    $result = $db->query("SELECT DISTINCT category FROM menu_items");
    echo "Menu categories:\n";
    while ($row = $result->fetch_assoc()) {
        echo "  - " . $row['category'] . "\n";
    }
    echo "\n";

    // Sample menu items
    $result = $db->query("SELECT name, price, category FROM menu_items LIMIT 5");
    echo "Sample menu items:\n";
    while ($row = $result->fetch_assoc()) {
        echo "  - " . $row['name'] . " ($" . $row['price'] . ") - " . $row['category'] . "\n";
    }

    echo "\n✓ All database tests PASSED!\n";

} catch (Exception $e) {
    echo "✗ Database connection FAILED!\n";
    echo "Error: " . $e->getMessage() . "\n";
}
?>
