<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();

// Original image names from the database
$originalImages = [
    1 => 'espresso.jpg',
    2 => 'americano.jpg',
    3 => 'latte.jpg',
    4 => 'cappuccino.jpg',
    5 => 'mocha.jpg',
    6 => 'iced-latte.jpg',
    7 => 'cold-brew.jpg',
    8 => 'iced-americano.jpg',
    9 => 'croissant.jpg',
    10 => 'muffin.jpg',
    11 => 'cookie.jpg',
    12 => 'almond-croissant.jpg',
    13 => 'avocado-toast.jpg',
    14 => 'turkey-sandwich.jpg'
];

echo "Reverting image paths to original values...\n\n";

foreach ($originalImages as $id => $imageName) {
    $stmt = $db->prepare("UPDATE menu_items SET image_path = ? WHERE id = ?");
    $stmt->bind_param("si", $imageName, $id);
    $stmt->execute();

    // Get item name for display
    $result = $db->query("SELECT name FROM menu_items WHERE id = $id");
    $row = $result->fetch_assoc();

    echo "Reverted ID $id ({$row['name']}): $imageName\n";
}

echo "\n✓ All menu item images reverted to original values!\n";
?>
