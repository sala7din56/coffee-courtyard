<?php
$cssPath = 'D:/xampp/htdocs/coffee-courtyard-main/coffee-courtyard-main/public/css/dist.css';

// Additional CSS for order page improvements
$additionalCss = '
/* Order page improvements */
.line-clamp-2{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.bg-black\/50{background-color:rgba(0,0,0,0.5)}
.bg-green-100{background-color:#dcfce7}
.text-green-800{color:#166534}
.bg-red-100{background-color:#fee2e2}
.text-red-800{color:#991b1b}
.text-red-500{color:#ef4444}
.text-red-700{color:#b91c1c}
.focus\:ring-primary\/50:focus{--tw-ring-color:rgba(221,161,94,0.5)}
.inset-0{top:0;right:0;bottom:0;left:0}
.fixed{position:fixed}
.z-40{z-index:40}
.z-50{z-index:50}
.bottom-4{bottom:1rem}
.right-4{right:1rem}
.top-4{top:1rem}
.w-5{width:1.25rem}
.h-5{height:1.25rem}
.w-6{width:1.5rem}
.w-7{width:1.75rem}
.h-7{height:1.75rem}
.h-40{height:10rem}
.max-h-64{max-height:16rem}
.max-w-sm{max-width:24rem}
.shadow-lg{box-shadow:0 10px 15px -3px rgba(0,0,0,0.1),0 4px 6px -4px rgba(0,0,0,0.1)}
.hover\:shadow-md:hover{box-shadow:0 4px 6px -1px rgba(0,0,0,0.1),0 2px 4px -2px rgba(0,0,0,0.1)}
@media (min-width:1024px){
.lg\:hidden{display:none}
.lg\:block{display:block}
.lg\:relative{position:relative}
.lg\:inset-auto{top:auto;right:auto;bottom:auto;left:auto}
.lg\:bg-transparent{background-color:transparent}
.lg\:col-span-2{grid-column:span 2/span 2}
.lg\:col-span-1{grid-column:span 1/span 1}
.lg\:max-w-none{max-width:none}
.lg\:sticky{position:sticky}
.lg\:top-24{top:6rem}
.lg\:rounded-xl{border-radius:0.75rem}
.lg\:shadow-lg{box-shadow:0 10px 15px -3px rgba(0,0,0,0.1),0 4px 6px -4px rgba(0,0,0,0.1)}
.lg\:border{border-width:1px}
.lg\:grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))}
}
';

// Read existing CSS and append
$existingCss = file_get_contents($cssPath);
$existingCss .= $additionalCss;
file_put_contents($cssPath, $existingCss);

echo "CSS updated with order page styles!\n";
?>
