<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();

$newHeroTitle = "Every cup holds a new beginning and Your dreams need caffeine too";
$contentKey = "hero_title"; // Assuming this is the key for the hero section title

try {
    $query = "UPDATE homepage_content SET content_text = ? WHERE section_name = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("ss", $newHeroTitle, $contentKey);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Hero section title updated successfully to: " . $newHeroTitle . "\n";
    } else {
        echo "No changes made or content key not found. Please check if 'hero_title' exists in homepage_content.\n";
    }
} catch (Exception $e) {
    echo "Error updating hero section title: " . $e->getMessage() . "\n";
}

$db->close();
?>
