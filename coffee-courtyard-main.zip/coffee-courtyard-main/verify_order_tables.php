<?php
require_once __DIR__ . '/coffee-courtyard-main/includes/config.php';
require_once __DIR__ . '/coffee-courtyard-main/includes/db.php';

$db = new Database();

echo "Verifying 'orders' and 'order_items' tables...\n";
echo "===============================================\n\n";

try {
    // Attempt to insert a dummy order
    $customerName = "Test Customer";
    $phone = "123-456-7890";
    $total = 9.99;

    $db->beginTransaction();

    $query = "INSERT INTO orders (customer_name, phone, total) VALUES (?, ?, ?)";
    $stmt = $db->prepare($query);
    $stmt->bind_param("ssd", $customerName, $phone, $total);
    $stmt->execute();
    $orderId = $db->lastInsertId();

    if ($orderId) {
        echo "✓ Successfully inserted dummy order (ID: {$orderId}) into 'orders' table.\n";

        // Attempt to insert a dummy order item
        $menuId = 1; // Assuming a menu item with ID 1 exists
        $qty = 1;
        $unitPrice = 9.99;

        $query = "INSERT INTO order_items (order_id, menu_id, qty, unit_price) VALUES (?, ?, ?, ?)";
        $stmt = $db->prepare($query);
        $stmt->bind_param("iiid", $orderId, $menuId, $qty, $unitPrice);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "✓ Successfully inserted dummy order item into 'order_items' table.\n";
            $db->commit();
            echo "\nTables 'orders' and 'order_items' are functional.\n";
        } else {
            $db->rollback();
            echo "✗ Failed to insert dummy order item into 'order_items' table.\n";
            echo "Error: " . $db->error . "\n";
        }

    } else {
        $db->rollback();
        echo "✗ Failed to insert dummy order into 'orders' table.\n";
        echo "Error: " . $db->error . "\n";
    }

} catch (Exception $e) {
    $db->rollback();
    echo "✗ An error occurred: " . $e->getMessage() . "\n";
} finally {
    // Clean up: delete the dummy order
    if (isset($orderId) && $orderId) {
        $db->query("DELETE FROM orders WHERE id = " . $orderId);
        echo "Cleaned up dummy order with ID: " . $orderId . "\n";
    }
}

$db->close();
?>
